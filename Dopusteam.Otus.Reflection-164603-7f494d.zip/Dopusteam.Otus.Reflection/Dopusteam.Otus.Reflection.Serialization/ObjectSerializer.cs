﻿namespace Dopusteam.Otus.Reflection.Serialization;

public static class Serializer
{
    public static 
}