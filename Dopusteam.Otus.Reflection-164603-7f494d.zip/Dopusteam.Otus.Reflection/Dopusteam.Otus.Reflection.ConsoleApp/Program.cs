﻿// See https://aka.ms/new-console-template for more information

using System.Text;
using Dopusteam.Otus.Reflection.ConsoleApp.Examples;

// Console.WriteLine(TaskExample.HasDifference(1, 2));
// Console.WriteLine(TaskExample.HasDifference(1, 1));
//
// #region object difference
//
// Console.WriteLine(TaskExample.HasDifference(new StringBuilder(), new StringBuilder()));
//
// #endregion

// StringReflection.Run();
ComparerExample.Run();
// DeserializerExample.Run();
AssemblyExample.Run();
// DynamicExample.Run();
AttributesExample.Run();